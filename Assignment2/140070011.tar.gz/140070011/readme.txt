Organization of the folder
--./planner.sh is the main executable file which takes in input --mdp, --algorithm --randomseed and --batchsize
--mdp_planner.py is called by planner.sh which then executes the corresponding algorithm implemented in mdp_algos.
--mdp_creator creates the mdp files.
--all_c.pkl is the pickle file which contains the experimental data for 100 MDP50.txt files.
--data_plotter.py takes in values from all_c.pkl and generates the graph which is reproduced in the report. It requires matplotlib.
--140070011_CS747_Assignment2.pdf is the report file.

As such mdp_planner requires numpy for python3. A bug has been filed in the cse bug tracking system.

In the case the code isn't working, do
pip3 install numpy

The codes are tested on sl2-15 machine.
