python mdp_planner.py $@
